﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Main
{
    public static class Globals
    {
        public static UserCredential CUR_USER { get; set; }

    }
}
